package com.gl.javafsd.leapyear;

public class MyClass2 {

	void println() {
		
		MyClass.myStaticMethod();
	}
}
