
public class ArrayDeclarations {

	public static void main(String[] args) {
		
		int []a = new int[5];
		
		int b[];
		b = new int[5];
		
		
	}
}
