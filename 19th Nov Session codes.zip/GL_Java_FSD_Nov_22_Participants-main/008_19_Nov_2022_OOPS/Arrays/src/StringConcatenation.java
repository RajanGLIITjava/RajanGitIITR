
public class StringConcatenation {

	public static void main(String[] args) {
		
		String welcome = "Welcome";
		
		String everyone = "Everyone";
		
		String finalMessage = 
				welcome + " " + everyone;
		
		System.out.println(finalMessage);
	}
}
