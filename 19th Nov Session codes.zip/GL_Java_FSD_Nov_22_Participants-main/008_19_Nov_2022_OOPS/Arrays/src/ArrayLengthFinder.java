
public class ArrayLengthFinder {

	public static void main(String[] args) {
		
		
		int array[] = new int[100];
		
		System.out.println("Length is " + array.length);
	}
}
